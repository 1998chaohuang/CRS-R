package com.example.www44.memorandum;

import android.app.Activity;
import android.os.Bundle;

import androidx.annotation.Nullable;

public class fanganActivity extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fangan);
    }
}