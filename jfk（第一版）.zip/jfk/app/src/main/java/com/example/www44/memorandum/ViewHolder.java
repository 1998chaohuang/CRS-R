package com.example.www44.memorandum;


import android.widget.Button;
import android.widget.TextView;

/**

 */

public class ViewHolder {
    TextView contenttv;
    TextView tvName;
    TextView tvReason;
    TextView tvResult;
    TextView tvHappenDay;
    TextView tvHospitalDay;
    TextView timetv;
}
