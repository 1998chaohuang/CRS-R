package com.example.www44.memorandum;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class zhujiemianActivity extends AppCompatActivity implements View.OnClickListener {
    Button btn_url,btn_url2,btn_url3,btn_url4;

    Intent intent;  //设置为全局的

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.zhujiemian);

        btn_url=findViewById(R.id.bt1);
//        btn_url2=findViewById(R.id.bt2);
//        btn_url3=findViewById(R.id.bt3);
        btn_url4=findViewById(R.id.bt4);

        btn_url.setOnClickListener(this);
//        btn_url2.setOnClickListener(this);
//        btn_url3.setOnClickListener(this);
        btn_url4.setOnClickListener(this);

        btn_url=findViewById(R.id.bt1);

        btn_url.setOnClickListener(new View.OnClickListener() {

            //主界面的jfk按钮跳转到昏迷量表
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(zhujiemianActivity.this, MainActivity.class);
                startActivity(intent);
            }

        });

        btn_url4=findViewById(R.id.bt4);
        btn_url4.setOnClickListener(new View.OnClickListener() {

            //主界面的各个方案表按钮跳转到方案表
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(zhujiemianActivity.this,fanganActivity.class);
                startActivity(intent);
            }

        });


    }


    @Override
    public void onClick(View view) {



}
}
